(function(){
    angular.module('angularSpa')
.controller('MainCtrl', function($scope){
	$scope.items = [
      'Bower',
      'Sass',
      'Gulp'
    ];
});
})();
