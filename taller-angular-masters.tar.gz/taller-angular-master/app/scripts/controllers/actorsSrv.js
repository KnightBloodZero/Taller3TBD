angular.module('angularSpa')
    .service('actorsService', function($http){
        var urlBase = 'http://localhost:8080/sakila-backend/actors';
        this.getActors = function(){
            return $http.get(urlBase);
        };
    });
  
    .service('actorsinfoService', function($http){
        var urlBase = 'http://localhost:8080/sakila-backend/actors/';
        this.getActorsid = function(actorId){
        	
            return $http.get(urlBase+actorId);
        };
    });