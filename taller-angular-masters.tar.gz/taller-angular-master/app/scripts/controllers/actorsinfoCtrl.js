    angular.module('angularSpa')
    .controller('ActorsinfoCtrl',function($scope,$routeParams, actorsinfoService){
        $scope.actors =[];
        function getActorsid(){
            actorsinfoService.getActorsid($routeParams)
            .success(function(data){
                $scope.actors = data;
            })
            .error(function(error){
                $scope.status = 'Error al consultar por actores';
            });
        }
        getActorsid();
    });    


